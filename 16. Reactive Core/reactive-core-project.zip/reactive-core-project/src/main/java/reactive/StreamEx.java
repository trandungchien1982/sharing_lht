package reactive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamEx {

    private static Logger log = LoggerFactory.getLogger(StreamEx.class);
    private static AtomicLong count = new AtomicLong();

    public static void main(String[] args) {
        testConcurencyStream();

    }

    private static void testConcurencyStream() {

        List a = Arrays.asList("a", "b", "c", "d", "e").stream()
                .peek(t -> {

                    log.info("Xu ly item: {}", t);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }


                    // Dummy
                    if (t == "c") {
                        try {
                            Thread.sleep(10*1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                })
                .collect(Collectors.toList());
    }


}
