package reactive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.ConnectableFlux;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class ConcurrencyExamples {

    private static Logger log = LoggerFactory.getLogger(ConcurrencyExamples.class);
    private static AtomicLong count = new AtomicLong();

    public static void main(String[] args) {
        testConcurencyStream();

    }

    private static void testConcurencyStream() {

        List<Integer> elements = new ArrayList<>();

        log.info("");
        log.info("Start testConcurencyStream: ");
        Flux.just(1, 2, 3, 4)
                .log()
                .map(i -> i * 2)
                .subscribeOn(Schedulers.parallel())
                .subscribe(elements::add);

        log.info("The result elements: {}", elements);
    }


}
