package reactive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.List;

public class StreamOpExamples {

    private static Logger log = LoggerFactory.getLogger(StreamOpExamples.class);

    public static void main(String[] args) {
        testMapItems();
        testZipItems();
    }

    private static void testMapItems() {
        List<Integer> elements = new ArrayList<>();

        log.info("");
        log.info("Start testMapItems: ");
        Flux.just(1, 2, 3, 4)
                .log()
                .map(i -> i*3)
                .subscribe(elements::add);

        log.info("Gia tri cua elements - FLUX: {}", elements);
    }

    private static void testZipItems() {
        List<String> elements = new ArrayList<>();

        log.info("");
        log.info("Start testZipItems: ");
        Flux.just(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
                .log()
                .map(i -> i*4)
                .zipWith(
                        Flux.just("Chuoi 01","Chuoi 02","Chuoi 03","Chuoi 04", "Chuoi 05"),
                        (intVal, str) -> String.format("[Value01 = %d] and [Value02 = %s]", intVal, str)
                )
                .subscribe(elements::add);

        log.info("Gia tri cua elements - testZipItems: ");
        for (String it: elements) {
            log.info("  >> Current value: {}", it);
        }
    }


}
