package reactive;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


import java.util.ArrayList;
import java.util.List;

public class SubscribeExamples {

    private static Logger log = LoggerFactory.getLogger(SubscribeExamples.class);

    public static void main(String[] args) {
//        testSubscribeFlux();
//        testSubscribeMono();
//        testSubscribeFlux2WithConsumer();
//        testSubscribeMono2WithConsumer();
//        testSubscribeFluxFull();
        testSubscribeFluxFull2();
    }

    private static void testSubscribeFlux() {
        List<Integer> elements = new ArrayList<>();

        log.info("");
        log.info("Start testSubscribeFlux: ");
        Flux.just(1, 2, 3, 4)
                .log()
                .subscribe(elements::add);

        log.info("Gia tri cua elements - FLUX: {}", elements);
    }

    private static void testSubscribeMono() {
        List<Integer> elements = new ArrayList<>();

        log.info("");
        log.info("Start testSubscribeMono: ");
        Mono.just(1)
                .log()
                .subscribe(elements::add);

        log.info("Gia tri cua elements - MONO: {}", elements);
    }

    private static void testSubscribeFlux2WithConsumer() {

        log.info("");
        log.info("\nStart testSubscribeFlux2WithConsumer: ");
        Flux.just(1, 2, 3, 4)
                .log()
                .subscribe(t -> {
                    log.info("Subscribe & xu ly item: {}", t);
                });
    }

    private static void testSubscribeMono2WithConsumer() {

        log.info("");
        log.info("\nStart testSubscribeMono2WithConsumer: ");
        Mono.just(1)
                .log()
                .subscribe(t -> {
                    log.info("Subscribe & xu ly item: {}", t);
                });
    }

    private static void testSubscribeFluxFull() {

        log.info("");
        log.info("Start testSubscribeFluxFull: Request 5 messages");
        Flux.just(1, 2, 3, 31, 32, 33, 34, 35, 4, 5, 6, 7)
                .log()
                .subscribe(new Subscriber<Integer>() {
                    @Override
                    public void onSubscribe(Subscription subscription) {
                        log.info("onSubscribe: {}", subscription);
                        //subscription.request(Long.MAX_VALUE);
                        // Số lượng items cần requests: 5
                        subscription.request(5);
                    }

                    @Override
                    public void onNext(Integer integer) {
                        log.info("onNext: {}", integer);
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        log.info("onError: {}", throwable);
                    }

                    @Override
                    public void onComplete() {
                        log.info("onComplete()");
                    }
                });

    }

    private static void testSubscribeFluxFull2() {

        log.info("");
        log.info("Start testSubscribeFluxFul2l: Total message requests: 2+3+4+5 = 14");
        Flux.just(1, 2, 3, 31, 32, 33, 34, 35, 36, 4, 5, 6, 7, 8, 9, 10, 11, 12)
                .log()
                .subscribe(new Subscriber<Integer>() {
                    int requestItems = 5;
                    Subscription s;

                    @Override
                    public void onSubscribe(Subscription subscription) {
                        log.info("onSubscribe: {}", subscription);
                        //subscription.request(Long.MAX_VALUE);

                        // Số lượng items cần requests: requestItems {2,3,4}
                        log.info("Number of request items: {}", requestItems);
                        subscription.request(requestItems);

                        this.s = subscription;
                    }

                    @Override
                    public void onNext(Integer integer) {
                        log.info("onNext: {}", integer);

                        requestItems++;
                        if (requestItems <= 5) {
//                            log.info("Number of request items: {}", requestItems);
//                            this.s.request(requestItems);
                        }

//                        if (integer == 3) {
//                            throw new NullPointerException("TEMP EXCEPTION");
//                        }
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        log.info("onError: {}", throwable);
                    }

                    @Override
                    public void onComplete() {
                        log.info("onComplete()");
                    }
                });

    }
}
