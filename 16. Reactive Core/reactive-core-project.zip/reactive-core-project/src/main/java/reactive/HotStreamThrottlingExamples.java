package reactive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.ConnectableFlux;
import reactor.core.publisher.Flux;

import java.time.Duration;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

public class HotStreamThrottlingExamples {

    private static Logger log = LoggerFactory.getLogger(HotStreamThrottlingExamples.class);
    private static AtomicLong count = new AtomicLong();

    public static void main(String[] args) {
        testInfiniteHotStreamWithThrottling();

    }

    private static void testInfiniteHotStreamWithThrottling() {

        log.info("");
        log.info("Start testInfiniteHotStreamWithThrottling: ");
        ConnectableFlux<Object> publish = Flux.create(fluxSink -> {
            while(true) {
                fluxSink.next(System.currentTimeMillis());
            }
        })
                .sample(Duration.ofSeconds(2))
                .publish();

        publish.subscribe(System.out::println);
        publish.subscribe(obj -> {
            log.info("Xu ly object: thu {}: , value: {}, current time: {}", count.getAndIncrement(), obj, new Date());
        });

        log.info("Publish chua he xu ly gi het. Cho 5s");
        for(int i = 1; i <= 5; i++) {
            log.info("Waiting at second: {}", i);
            try {
                Thread.sleep(1000);
            } catch(Exception ex) {}
        }

        log.info("Finish waiting. Start connect ...");
        publish.connect();

    }


}
