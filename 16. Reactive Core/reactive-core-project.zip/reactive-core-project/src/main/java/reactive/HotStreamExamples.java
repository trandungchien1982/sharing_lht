package reactive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.ConnectableFlux;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class HotStreamExamples {

    private static Logger log = LoggerFactory.getLogger(HotStreamExamples.class);
    private static AtomicLong count = new AtomicLong();

    public static void main(String[] args) {
        testInfiniteHotStream();

    }

    private static void testInfiniteHotStream() {

        log.info("");
        log.info("Start testInfiniteHotStream: ");
        ConnectableFlux<Object> publish = Flux.create(fluxSink -> {
            while(true) {
                fluxSink.next(System.currentTimeMillis());
            }
        }).publish();

        publish.subscribe(System.out::println);
        publish.subscribe(obj -> {
            log.info("Xu ly object: thu {}: , value: {}", count.getAndIncrement(), obj);
        });

        log.info("Publish chua he xu ly gi het. Cho 5s");
        for(int i = 1; i <= 5; i++) {
            log.info("Waiting at second: {}", i);
            try {
                Thread.sleep(1000);
            } catch(Exception ex) {}
        }

        log.info("Finish waiting. Start connect ...");
        publish.connect();

    }


}
